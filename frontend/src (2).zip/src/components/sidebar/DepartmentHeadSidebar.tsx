/*
import { NavLink } from 'react-router-dom';
import { roleNavigation } from '../../config/roleNavigation';

interface DepartmentHeadSidebarProps {
  collapsed: boolean;
  onToggleCollapse: () => void;
}

const DepartmentHeadSidebar = ({
  collapsed,
  onToggleCollapse,
}: DepartmentHeadSidebarProps) => {
  return (
    <aside className={`employee-sidebar ${collapsed ? 'collapsed' : ''}`}>
      <div className="employee-sidebar-top">
        <div className="employee-brand">
          <div className="employee-brand-mark">
            <i className="bi bi-building-check" />
          </div>

          {!collapsed && (
            <div className="employee-brand-copy">
              <h2>EPMS</h2>
              <p>PERFORMANCE SYSTEM</p>
            </div>
          )}
        </div>
      </div>

      {!collapsed && (
        <div className="employee-role-chip">
          <p>CURRENT ROLE</p>
          <strong>Department Head</strong>
        </div>
      )}

      <nav className="employee-nav">
        {roleNavigation.DepartmentHead.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            end={item.end}
            title={collapsed ? item.label : undefined}
            className={({ isActive }) =>
              `employee-nav-link ${isActive ? 'active' : ''} ${collapsed ? 'collapsed' : ''}`
            }
          >
            <i className={`bi ${item.icon}`} />
            {!collapsed && <span>{item.label}</span>}
          </NavLink>
        ))}
      </nav>

      <div className="employee-sidebar-footer">
        <button
          type="button"
          onClick={onToggleCollapse}
          className="employee-sidebar-collapse"
          aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          <i className={`bi ${collapsed ? 'bi-chevron-right' : 'bi-chevron-left'}`} />
          {!collapsed && <span>Collapse</span>}
        </button>
      </div>
    </aside>
  );
};

export default DepartmentHeadSidebar;
 */


/*
DepartmentHeadSidebar.tsx file: */



/* DepartmentHeadSidebar.tsx
   Why this file is fixed:
   - Uses the same dropdown-capable sidebar as Manager/Employee.
   - Department Head now gets:
     PIP
       Create
       Past Plans
*/

import EmployeeSidebar from './EmployeeSidebar';

interface DepartmentHeadSidebarProps {
  collapsed: boolean;
  onToggleCollapse: () => void;
}

const DepartmentHeadSidebar = ({
  collapsed,
  onToggleCollapse,
}: DepartmentHeadSidebarProps) => {
  return (
    <EmployeeSidebar
      role="DepartmentHead"
      collapsed={collapsed}
      onToggleCollapse={onToggleCollapse}
    />
  );
};

export default DepartmentHeadSidebar;
